package AltoroJ_00202_002e1.bank;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.jsp.*;
import java.util.Date;
import com.ibm.rational.appscan.altoromutual.model.Transaction;

public final class transaction_jsp extends org.apache.jasper.runtime.HttpJspBase
    implements org.apache.jasper.runtime.JspSourceDependent {

  private static java.util.Vector _jspx_dependants;

  public java.util.List getDependants() {
    return _jspx_dependants;
  }

  public void _jspService(HttpServletRequest request, HttpServletResponse response)
        throws java.io.IOException, ServletException {

    JspFactory _jspxFactory = null;
    PageContext pageContext = null;
    HttpSession session = null;
    ServletContext application = null;
    ServletConfig config = null;
    JspWriter out = null;
    Object page = this;
    JspWriter _jspx_out = null;
    PageContext _jspx_page_context = null;


    try {
      _jspxFactory = JspFactory.getDefaultFactory();
      response.setContentType("text/html; charset=ISO-8859-1");
      pageContext = _jspxFactory.getPageContext(this, request, response,
      			null, true, 8192, true);
      _jspx_page_context = pageContext;
      application = pageContext.getServletContext();
      config = pageContext.getServletConfig();
      session = pageContext.getSession();
      out = pageContext.getOut();
      _jspx_out = out;

      out.write("\r\n    \r\n");
      org.apache.jasper.runtime.JspRuntimeLibrary.include(request, response, "/header.jspf", out, false);
      out.write("\r\n\r\n<div id=\"wrapper\" style=\"width: 99%;\">\r\n\t");
      org.apache.jasper.runtime.JspRuntimeLibrary.include(request, response, "membertoc.jspf", out, false);
      out.write("\r\n    <td valign=\"top\" colspan=\"3\" class=\"bb\">\r\n    \r\n\t\t\r\n\t\t\r\n\t\t\r\n\t\t<div class=\"fl\" style=\"width: 99%;\">\r\n\t\t\r\n\t\t");

		com.ibm.rational.appscan.altoromutual.model.User user = (com.ibm.rational.appscan.altoromutual.model.User)request.getSession().getAttribute("user");
		String startString = request.getParameter("startTime");
		String endString = request.getParameter("endTime");
		Date startDate = null;
		Date endDate = null;
		try {
			startDate = new Date(Long.valueOf(startString));
		} catch (Exception e){
			//do nothing
		}
		
		try {
			endDate = new Date(Long.valueOf(endString));
		} catch (Exception e){
			//do nothing
		}
		
		Transaction[] transactions = user.getUserTransactions(startDate, endDate, user.getAccounts());
		
      out.write("\r\n\t\t\r\n\t\t<h1>Recent Transactions</h1>\r\n\t\t\r\n\t\t<script type=\"text/javascript\">\r\n\t\t\tfunction confirminput(myform) {\r\n\t\t\t\r\n\t\t\t\tif (myform.startDate.value != \"\"){\r\n\t\t\t\t\tvar splitStrings = myform.startDate.value.split(\"/\");\r\n\t\t\t\t\tvar month = parseInt((splitStrings[0].charAt(0)==0 && splitStrings[0].length == 2)?splitStrings[0].charAt(1):splitStrings[0]);\r\n\t\t\t\t\tvar day = parseInt((splitStrings[1].charAt(0)==0 && splitStrings[1].length == 2)?splitStrings[1].charAt(1):splitStrings[1]);\r\n\t\t\t\t\tvar year = parseInt(splitStrings[2]);\r\n\t\t\t\t\t\r\n\t\t\t\t\tvar valid = validateDate(month, day, year);\r\n\t\t\t\t\tif (!valid){\r\n\t\t\t\t\t\talert (\"'After' date of \" + myform.startDate.value + \" is not valid.\");\r\n\t\t\t\t\t\treturn false;\r\n\t\t\t\t\t}\r\n\t\t\t\t}\r\n\t\t\t\r\n\t\t\t\tif (myform.endDate.value != \"\"){\r\n\t\t\t\t\tvar splitStrings2 = myform.endDate.value.split(\"/\");\r\n\t\t\t\t\tvar month2 = parseInt((splitStrings2[0].charAt(0)==0 && splitStrings2[0].length == 2)?splitStrings2[0].charAt(1):splitStrings2[0]);\r\n\t\t\t\t\tvar day2 = parseInt((splitStrings2[1].charAt(0)==0 && splitStrings2[1].length == 2)?splitStrings2[1].charAt(1):splitStrings2[1]);\r\n");
      out.write("\t\t\t\t\tvar year2 = parseInt(splitStrings2[2]);\r\n\t\t\t\r\n\t\t\t\t\tvar valid2 = validateDate(month2, day2, year2);\r\n\t\t\t\t\tif (!valid2){\r\n\t\t\t\t\t\talert (\"'Before' date of \" + myform.endDate.value + \" is not valid.\");\r\n\t\t\t\t\t}\r\n\t\t\t\t}\r\n\t\t\t\t\r\n\t\t\t}\r\n\t\t\t\r\n\t\t\tfunction validateDate(month, day, year){\r\n\t\t\t\ttry {\r\n\t\t\t\t\tvar thisDate = new Date();\r\n\t\t\t\t\tvar wrongMonth = month<1 || month>12;\r\n\t\t\t\t\tvar wrongDay = (day<1) || (day>31) || (day>30 && ((month==4)||(month==6)||(month==9)||(month==11))) || (day>29 && month==2 && (year%4==0) && (year%100!=0 || year%400==0)) || (day>28 && month==2 && ((year%4!=0) || (year%100==0 && year%400!=0))); \r\n\t\t\t\t\tvar wrongYear = year < 1990 || year > parseInt(thisDate.getFullYear());\r\n\t\t\t\r\n\t\t\t\t\tvar thisYear = parseInt(thisDate.getFullYear());\r\n\t\t\t\t\tvar thisMonth = parseInt(thisDate.getMonth())+1;\r\n\t\t\t\t\tvar thisDay = parseInt(thisDate.getDate());\r\n\t\t\t\t\tvar wrongDate = year==thisYear && ((thisMonth<month) || (thisMonth==month && thisDay<(day-1)));\r\n\t\t\t\r\n\t\t\t\t\tif (wrongMonth ||wrongDay || wrongYear || wrongDate)\r\n");
      out.write("\t\t\t\t\t\treturn false;\r\n\t\t\t\t\t\r\n\t\t\t\t\t} catch (error){\r\n\t\t\t\t\t\treturn false;\r\n\t\t\t\t\t}\r\n\t\t\t\t\t\r\n\t\t\t\t\treturn true;\r\n\t\t\t}\r\n\t\t</script>\r\n\t\t\r\n\t\t\r\n\t\t<form id=\"Form1\" name=\"Form1\" method=\"post\" action=\"showTransactions\" onsubmit=\"return (confirminput(Form1));\">\r\n\t\t<table border=\"0\" style=\"padding-bottom:10px;\">\r\n\t\t    <tr>\r\n\t\t        <td valign=top>After</td>\r\n\t\t        <td><input id=\"startDate\" name=\"startDate\" type=\"text\" value=\"");
      out.print((request.getParameter("startDate")==null)?"":request.getParameter("startDate"));
      out.write("\"/><br /><span class=\"credit\">mm/dd/yyyy</span></td>\r\n\t\t        <td valign=top>Before</td>\r\n\t\t        <td><input name=\"endDate\" id=\"endDate\" type=\"text\" value=\"");
      out.print((request.getParameter("endDate")==null)?"":request.getParameter("endDate") );
      out.write("\"/><br /><span class=\"credit\">mm/dd/yyyy</span></td>\r\n\t\t        <td valign=top><input type=submit value=Submit /></td>\r\n\t\t    </tr>\r\n\t\t</table>\r\n\t\t\r\n\t\t<table cellspacing=\"0\" cellpadding=\"3\" rules=\"all\" border=\"1\" id=\"_ctl0__ctl0_Content_Main_MyTransactions\" style=\"width:100%;border-collapse:collapse;\">\r\n\t\t\t<tr style=\"color:White;background-color:#BFD7DA;font-weight:bold;\">\r\n\t\t\t\t<td>TransactionID</td><td>AccountId</td><td>Description</td><td>Amount</td>\r\n\t\t\t</tr>\r\n\t\t\t");
 for (int i=0; i<transactions.length; i++){
				//limit to 100 entries
				if (i==100)
					break;
			
      out.write("\r\n\t\t\r\n\t\t\t\t<tr><td>");
      out.print(transactions[i].getTransactionId());
      out.write("</td><td>");
      out.print(transactions[i].getAccountId());
      out.write("</td><td>");
      out.print(transactions[i].getTransactionType());
      out.write("</td><td align=\"right\">");
      out.print(transactions[i].getAmount());
      out.write("</td></tr>\r\n\t\t\t");
 } 
      out.write("\r\n\t\t<tr>\r\n\t\t<!-- TODO PAGES: <td colspan=\"4\"><span>1</span>&nbsp;<a href=\"javascript:__doPostBack('_ctl0$_ctl0$Content$Main$MyTransactions$_ctl54$_ctl1','')\">2</a></td> -->\r\n\t\t\t</tr>\r\n\t\t</table>\r\n\t\t\r\n\t\t</form>\r\n\t\t\r\n\t\t</div>    \r\n    \r\n    </td>\t\r\n</div>\r\n\r\n");
      org.apache.jasper.runtime.JspRuntimeLibrary.include(request, response, "/footer.jspf", out, false);
      out.write(' ');
      out.write(' ');
    } catch (Throwable t) {
      if (!(t instanceof SkipPageException)){
        out = _jspx_out;
        if (out != null && out.getBufferSize() != 0)
          out.clearBuffer();
        if (_jspx_page_context != null) _jspx_page_context.handlePageException(t);
      }
    } finally {
      if (_jspxFactory != null) _jspxFactory.releasePageContext(_jspx_page_context);
    }
  }
}
