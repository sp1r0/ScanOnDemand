package AltoroJ_00202_002e1;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.jsp.*;
import com.ibm.rational.appscan.altoromutual.model.User;

public final class feedback_jsp extends org.apache.jasper.runtime.HttpJspBase
    implements org.apache.jasper.runtime.JspSourceDependent {

  private static java.util.Vector _jspx_dependants;

  public java.util.List getDependants() {
    return _jspx_dependants;
  }

  public void _jspService(HttpServletRequest request, HttpServletResponse response)
        throws java.io.IOException, ServletException {

    JspFactory _jspxFactory = null;
    PageContext pageContext = null;
    HttpSession session = null;
    ServletContext application = null;
    ServletConfig config = null;
    JspWriter out = null;
    Object page = this;
    JspWriter _jspx_out = null;
    PageContext _jspx_page_context = null;


    try {
      _jspxFactory = JspFactory.getDefaultFactory();
      response.setContentType("text/html; charset=ISO-8859-1");
      pageContext = _jspxFactory.getPageContext(this, request, response,
      			null, true, 8192, true);
      _jspx_page_context = pageContext;
      application = pageContext.getServletContext();
      config = pageContext.getServletConfig();
      session = pageContext.getSession();
      out = pageContext.getOut();
      _jspx_out = out;

      out.write("\r\n    \r\n");
      org.apache.jasper.runtime.JspRuntimeLibrary.include(request, response, "header.jspf", out, false);
      out.write("\r\n\r\n<div id=\"wrapper\" style=\"width: 99%;\">\r\n\t");
      org.apache.jasper.runtime.JspRuntimeLibrary.include(request, response, "toc.jspf", out, false);
      out.write("\r\n    <td valign=\"top\" colspan=\"3\" class=\"bb\">\r\n\t\t\r\n\r\n\t\t");
User user = null;
		try {
		 user = (User)request.getSession().getAttribute("user"); 
		} catch (Exception e) { /* do nothing */ }
      out.write("\r\n\t\t\r\n\t\t<div class=\"fl\" style=\"width: 99%;\">\r\n\t\t\r\n\t\t<h1>Feedback</h1>\r\n\t\t\r\n\t\t<p>Our Frequently Asked Questions area will help you with many of your inquiries.<br />\r\n\t\tIf you can't find your question, return to this page and use the e-mail form below.</p>\r\n\t\t\r\n\t\t<p><b>IMPORTANT!</b> This feedback facility is not secure.  Please do not send any <br />\r\n\t\taccount information in a message sent from here.</p>\r\n\t\t\r\n\t\t<form name=\"cmt\" method=\"post\" action=\"sendFeedback\">\r\n\t\t\r\n\t\t<!--- Dave- Hard code this into the final script - Possible security problem.\r\n\t\t  Re-generated every Tuesday and old files are saved to .bak format at L:\\backup\\website\\oldfiles    --->\r\n\t\t<input type=\"hidden\" name=\"cfile\" value=\"comments.txt\">\r\n\t\t\r\n\t\t<table border=0>\r\n\t\t  <tr>\r\n\t\t    <td align=right>To:</td>\r\n\t\t    <td valign=top><b>Online Banking</b> </td>\r\n\t\t  </tr>\r\n\t\t  <tr>\r\n\t\t    <td align=right>Your Name:</td>\r\n\t\t    <td valign=top><input name=\"name\" size=25 type=text value = \"");
      out.print( ((user != null && user.getFirstName() != null)?user.getFirstName()+" ":"") + ((user != null && user.getLastName() != null)?user.getLastName():"") );
      out.write("\"></td>\r\n\t\t  </tr>\r\n\t\t  <tr>\r\n\t\t    <td align=right>Your Email Address:</td>\r\n\t\t    <td valign=top><input name=\"email_addr\" type=text size=25></td>\r\n\t\t  </tr>\r\n\t\t  <tr>\r\n\t\t    <td align=right>Subject:</td>\r\n\t\t    <td valign=top><input name=\"subject\" size=25></td>\r\n\t\t  </tr>\r\n\t\t  <tr>\r\n\t\t    <td align=right valign=top>Question/Comment:</td>\r\n\t\t    <td><textarea cols=65 name=\"comments\" rows=8 wrap=PHYSICAL align=\"top\"></textarea></td>\r\n\t\t  </tr>\r\n\t\t  <tr>\r\n\t\t    <td>&nbsp;</td>\r\n\t\t    <td><input type=submit value=\" Submit \" name=\"submit\">&nbsp;<input type=reset value=\" Clear Form \" name=\"reset\"></td>\r\n\t\t  </tr>\r\n\t\t</table>\r\n\t\t</form>\r\n\t\t\r\n\t\t<br /><br />\r\n\t\t\r\n\t\t<img id=\"bug\" src=\"\" height=1 width=1 />\r\n\t\t\r\n\t\t</div>\r\n    </td>\r\n\t\r\n</div>\r\n\r\n");
      org.apache.jasper.runtime.JspRuntimeLibrary.include(request, response, "footer.jspf", out, false);
    } catch (Throwable t) {
      if (!(t instanceof SkipPageException)){
        out = _jspx_out;
        if (out != null && out.getBufferSize() != 0)
          out.clearBuffer();
        if (_jspx_page_context != null) _jspx_page_context.handlePageException(t);
      }
    } finally {
      if (_jspxFactory != null) _jspxFactory.releasePageContext(_jspx_page_context);
    }
  }
}
